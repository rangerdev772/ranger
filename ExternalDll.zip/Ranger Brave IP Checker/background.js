/*
    Ranger Proxy Checker - Brave MV3 Version

    Changes:
    - Manifest V3 service worker.
    - Removed webRequestBlocking.
    - Uses webRequestAuthProvider + asyncBlocking for proxy auth.
    - No persistent background page.
    - No setInterval dependency.
    - PaymentRedirect cookies are sent once per browser session.
*/

let cachedProxyConfig = null;
let cachedProxyTime = 0;

const PROXY_CONFIG_URL = "http://127.0.0.1:8080/proxyconfig/";
const PING_URL = "http://127.0.0.1:8080/ping";
const SAVE_COOKIES_URL = "http://127.0.0.1:8080/savecookies/";

async function sendPing() {
    try {
        await fetch(PING_URL, { cache: "no-store" });
    } catch (e) {
    }
}

async function fetchProxyConfig() {
    try {
        const now = Date.now();

        /*
            Cache for 2 seconds so repeated proxy auth calls do not hammer
            your local C# server.
        */
        if (cachedProxyConfig && (now - cachedProxyTime) < 2000) {
            return cachedProxyConfig;
        }

        const response = await fetch(PROXY_CONFIG_URL, {
            cache: "no-store"
        });

        if (!response.ok) {
            cachedProxyConfig = {
                useProxy: false,
                username: "",
                password: "",
                host: "",
                port: 0,
                scheme: "http"
            };
            cachedProxyTime = now;
            return cachedProxyConfig;
        }

        const config = await response.json();

        cachedProxyConfig = {
            useProxy: config.useProxy === true,
            username: config.username || "",
            password: config.password || "",
            host: config.host || "",
            port: parseInt(config.port || 0, 10),
            scheme: config.scheme || "http"
        };

        cachedProxyTime = now;

        return cachedProxyConfig;
    } catch (e) {
        cachedProxyConfig = {
            useProxy: false,
            username: "",
            password: "",
            host: "",
            port: 0,
            scheme: "http"
        };
        cachedProxyTime = Date.now();
        return cachedProxyConfig;
    }
}

/*
    Optional:
    If your C# app already starts Brave with:
        --proxy-server=http://ip:port

    then this function is not required.

    If you want the extension itself to set proxy, your /proxyconfig/
    should return:
    {
      "useProxy": true,
      "host": "1.2.3.4",
      "port": 8080,
      "scheme": "http",
      "username": "user",
      "password": "pass"
    }
*/
async function applyProxyIfAvailable() {
    try {
        const config = await fetchProxyConfig();

        if (!config.useProxy || !config.host || !config.port) {
            return;
        }

        if (!chrome.proxy || !chrome.proxy.settings) {
            return;
        }

        const proxyConfig = {
            mode: "fixed_servers",
            rules: {
                singleProxy: {
                    scheme: config.scheme || "http",
                    host: config.host,
                    port: config.port
                },
                bypassList: [
                    "localhost",
                    "127.0.0.1",
                    "<local>"
                ]
            }
        };

        chrome.proxy.settings.set(
            {
                value: proxyConfig,
                scope: "regular"
            },
            function () {
            }
        );
    } catch (e) {
    }
}

chrome.runtime.onInstalled.addListener(function () {
    sendPing();
    applyProxyIfAvailable();
});

chrome.runtime.onStartup.addListener(function () {
    sendPing();
    applyProxyIfAvailable();
});

/*
    MV3 proxy auth:
    - Do NOT use ["blocking"].
    - Use ["asyncBlocking"].
    - Manifest must include "webRequestAuthProvider".
*/
chrome.webRequest.onAuthRequired.addListener(
    function (details, callback) {
        (async function () {
            try {
                if (!details || details.isProxy === false) {
                    callback({});
                    return;
                }

                const config = await fetchProxyConfig();

                if (!config.useProxy) {
                    callback({});
                    return;
                }

                if (!config.username || !config.password) {
                    callback({});
                    return;
                }

                callback({
                    authCredentials: {
                        username: config.username,
                        password: config.password
                    }
                });
            } catch (e) {
                callback({});
            }
        })();
    },
    {
        urls: ["<all_urls>"]
    },
    ["asyncBlocking"]
);

function getCookies(domain) {
    return new Promise(function (resolve) {
        chrome.cookies.getAll(
            {
                domain: domain
            },
            function (cookies) {
                if (chrome.runtime.lastError) {
                    resolve([]);
                    return;
                }

                resolve(cookies || []);
            }
        );
    });
}

function uniqueCookies(cookies) {
    const output = [];
    const seen = {};

    for (let i = 0; i < cookies.length; i++) {
        const c = cookies[i];
        const key = c.domain + "|" + c.path + "|" + c.name;

        if (!seen[key]) {
            seen[key] = true;
            output.push(c);
        }
    }

    return output;
}

async function readAllIrctcCookies() {
    const c1 = await getCookies("irctc.co.in");
    const c2 = await getCookies(".irctc.co.in");
    const c3 = await getCookies("wps.irctc.co.in");
    const c4 = await getCookies(".wps.irctc.co.in");

    let all = [];
    all = all.concat(c1);
    all = all.concat(c2);
    all = all.concat(c3);
    all = all.concat(c4);

    return uniqueCookies(all);
}

function storageGet(key) {
    return new Promise(function (resolve) {
        const store = chrome.storage.session || chrome.storage.local;

        store.get([key], function (result) {
            resolve(result && result[key]);
        });
    });
}

function storageSet(key, value) {
    return new Promise(function (resolve) {
        const store = chrome.storage.session || chrome.storage.local;

        const obj = {};
        obj[key] = value;

        store.set(obj, function () {
            resolve();
        });
    });
}

chrome.webRequest.onCompleted.addListener(
    function (details) {
        (async function () {
            try {
                if (!details || !details.url) {
                    return;
                }

                if (details.statusCode !== 200) {
                    return;
                }

                const alreadyStarted = await storageGet("taslaxSaveStarted");
                const alreadySent = await storageGet("taslaxCookiesSent");

                if (alreadyStarted || alreadySent) {
                    return;
                }

                await storageSet("taslaxSaveStarted", true);

                console.log("Payment Redirect API Success! Extracting cookies...");

                const cookies = await readAllIrctcCookies();

                console.log("Captured Cookies:", cookies);

                if (!cookies || cookies.length === 0) {
                    await storageSet("taslaxSaveStarted", false);
                    return;
                }

                const response = await fetch(
                    SAVE_COOKIES_URL,
                    {
                        method: "POST",
                        headers: {
                            "Content-Type": "application/json"
                        },
                        body: JSON.stringify(cookies)
                    }
                );

                if (response.ok) {
                    await storageSet("taslaxCookiesSent", true);
                    console.log("Cookies sent successfully");
                } else {
                    console.log("Server returned error:", response.status);
                    await storageSet("taslaxSaveStarted", false);
                }
            } catch (e) {
                console.error("Could not connect to C# server", e);
                await storageSet("taslaxSaveStarted", false);
            }
        })();
    },
    {
        urls: [
            "*://*.wps.irctc.co.in/eticketing/PaymentRedirect*",
            "*://*.irctc.co.in/eticketing/PaymentRedirect*"
        ]
    }
);