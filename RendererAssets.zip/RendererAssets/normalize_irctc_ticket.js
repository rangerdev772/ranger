/*
 * Adapt an authorized IRCTC booking response or printTicket DTO to the captured
 * print component's renderer context. No request, storage, or network activity.
 *
 * A booking response is not a printTicket response: invoice fields, exact fare
 * labels, instructions, and advertisements can be missing. A separately supplied
 * PDF reference profile may supplement only the ticket identified by that
 * profile. The generic mapper contains no ticket identity or invoice constants.
 *
 * normalizeIrctcTicket(input, {
 *   referenceProfile,               // optional, parsed reference_profile.json
 *   useReferenceProfile,            // false ignores all reference data
 *   useReferenceQr: false,          // explicit opt-in; input QR is preserved
 *   allowReferenceSupplementForPrintDto: false,
 *   iframeVisible,                  // optional component display override
 *   requireComplete: false          // throw when required fields are absent
 * })
 */
(function (root) {
  'use strict';

  const MONTHS = ['Jan', 'Feb', 'Mar', 'Apr', 'May', 'Jun', 'Jul', 'Aug', 'Sep', 'Oct', 'Nov', 'Dec'];
  const ACRONYMS = ['REMOTE LOCATION WAITLIST', 'POOLED QUOTA WAITLIST', 'ROAD-SIDE WAITLIST'];
  // A reference supplies print-only presentation/invoice data. Boarding,
  // scheduled journey times, passengers and identity remain supplied JSON facts.
  // In particular, no profile key may replace boardingAt/boardingAtName,
  // boardingDate, scheduledDepartureTime or passengerList after validation.
  const REFERENCE_PRINT_FIELDS = new Set([
    'classCode', 'quota', 'dateOfBooking',
    'gstFlag', 'invoiceNumber', 'suplierAddress', 'sacCode', 'gstinSuplier', 'gstDetailsDTO',
    'taxableAmt', 'cgstRate', 'prsCgstCharge', 'sgstRate', 'prsSgstCharge',
    'igstRate', 'prsIgstCharge', 'ugstRate', 'prsUgstCharge', 'totalPRSGst',
    'prsSuplierState', 'prsSuplierStateCode', 'gstStateName', 'gstStateCode',
    'fareInfoData', 'bottomTicketMessage', 'fundmntlTicketMessage', 'ticketLegendMessage',
    'accommodationStatus', 'ersLogosEnglish'
  ]);
  // Exact field names read by the captured print component. A booking envelope
  // may carry these at the root or under printTktResp. Copy only supplied values
  // and give the booking object precedence; do not infer missing invoice data.
  const SUPPLIED_PRINT_FIELDS = (`accommodationStatus addOnCancelCharge addOnCancellationId
    addOnRefundAmount addonCancelDate addonCancelPsgnFare addonServiceCharge addonServiceFlag
    agentAddress agentCompanyName agentEmailID agentMobileNumber agentName bedrollChoice
    boardingAt boardingAtName bottomTicketMessage cancelFareDetail cancellationID cgstRate
    classCode codPaymentMsgFlag concessionCode concessionOption curBkngMsg dateOfBooking
    dateOfJourney displayCateringFlag displayMPPhoto distance dmrcCarbonValue dmrcECSFlag
    dmrcOptedFlag dmrcServiceCharge ecsFlag emissionIntensity ersLogosEnglish fareInfoData
    fromStation fromStationName fromStnCityName fundmntlTicketMessage gsaFlag gstDetailsDTO
    gstDisplay gstFlag gstStateCode gstStateName gstinSuplier igstRate invoiceNumber linkPnr
    mainPnrType metroFromStation metroGstCharge metroJourneyDate metroPassengerList
    metroTicketFare metroToStation mlTransactionID mpPhoto nosbChildPnr nosbMainPnr
    numOfPsgnMetro otpInformativeMsgForPsgn passengerList pkmValue pmfAgentFlage pnrLinkStatus
    pnrNumber principleAgentName prsCgstCharge prsIgstCharge prsSgstCharge prsSuplierState
    prsSuplierStateCode prsUgstCharge qrCodeText quota railGreenPoint railGreenPointFlag
    reservationUpto reservationUptoName sacCode scheduleArrivalFlag scheduleDepartureFlag
    scheduledArrivalTime scheduledDepartureTime sgstRate suplierAddress tatkalIDChoice
    taxableAmt testingEnvFlag ticketLegendMessage toStnCityName totalPRSGst trainName trainNo
    trainOwnerFlag trainType transactionID travelAgentFlag txnType ugstRate userGroupTypeIdFlag
    userIdTkt userName vandeBharatCateringMsg waitlistOption`).split(/\s+/);
  const has = (x, key) => x != null && Object.prototype.hasOwnProperty.call(x, key);
  const present = x => x !== undefined && x !== null && x !== '';
  const array = x => x == null ? [] : Array.isArray(x) ? x : [x];
  const clone = x => x === undefined ? undefined : JSON.parse(JSON.stringify(x));
  const first = (...xs) => xs.find(present);
  const str = x => x == null ? '' : String(x);
  const flag = (x, fallback = 'false') => x == null ? fallback : String(x).toLowerCase();

  // Dates in these DTOs are ticket-local. Do not create a JavaScript Date or
  // convert through UTC: doing so can change the printed journey day/time.
  function dateOnly(value) {
    const text = str(value).trim();
    const iso = /^(\d{4})-(\d{2})-(\d{2})(?:[T ]|$)/.exec(text);
    if (iso) return `${iso[3]}-${MONTHS[Number(iso[2]) - 1]}-${iso[1]}`;
    const display = /\b(\d{1,2}-[A-Za-z]{3}-\d{4})\b/.exec(text);
    return display ? display[1] : text;
  }

  function scheduled(value, separateTime) {
    const text = str(value).trim();
    if (!text) return '';
    const display = /^(\d{2}:\d{2})(?::\d{2})?\s+(\d{1,2}-[A-Za-z]{3}-\d{4})$/.exec(text);
    if (display) return `${display[1]} ${display[2]}`;
    const api = /^(\d{1,2}-[A-Za-z]{3}-\d{4})\s+(\d{2}:\d{2})(?::\d{2})?$/.exec(text);
    if (api) return `${api[2]} ${api[1]}`;
    const isoTime = /[T ](\d{2}:\d{2})/.exec(text);
    const time = first(separateTime, isoTime && isoTime[1]);
    return time ? `${str(time).slice(0, 5)} ${dateOnly(text)}` : text;
  }

  function bookingDate(value) {
    const text = str(value).trim();
    const iso = /^(\d{4}-\d{2}-\d{2})T(\d{2}:\d{2}:\d{2})/.exec(text);
    return iso ? `${dateOnly(iso[1])} ${iso[2]} HRS` : text;
  }

  function qrField(qr, label) {
    const escaped = label.replace(/[.*+?^${}()|[\]\\]/g, '\\$&');
    const match = new RegExp(`^\\s*${escaped}\\s*:\\s*([^\\r\\n]*)`, 'im').exec(str(qr));
    return match ? match[1].replace(/,\s*$/, '').trim() : undefined;
  }

  function qrIdentity(qr) {
    const text = str(qr);
    const pnr = /^\s*PNR[^:\n]*:\s*(\d+)/im.exec(text);
    const txn = /^\s*TXN ID:\s*(\d+)/im.exec(text);
    return {
      pnrNumber: pnr && pnr[1],
      transactionId: txn && txn[1],
      trainNo: qrField(text, 'Train No.'),
      dateOfJourney: qrField(text, 'Date Of Journey')
    };
  }

  function inspectReferenceProfile(profile, dto) {
    const result = {status: 'missing', mismatchFields: [], invalidFields: []};
    if (profile == null) return result;
    if (!profile || profile.format !== 'irctc-reference-profile-v1') {
      result.status = 'invalid_format';
      result.invalidFields.push('format');
      return result;
    }
    const match = profile.match || {};
    // A profile without a ticket identity must never act as a global default.
    if (!present(match.pnrNumber)) {
      result.status = 'invalid_identity';
      result.invalidFields.push('match.pnrNumber');
      return result;
    }
    if (str(match.pnrNumber) !== str(dto.pnrNumber)) result.mismatchFields.push('pnrNumber');
    const actual = {
      transactionId: first(dto.mlTransactionID, dto.transactionID, dto.reservationId),
      trainNo: dto.trainNo,
      dateOfJourney: dto.dateOfJourney
    };
    for (const key of Object.keys(actual)) {
      if (present(actual[key]) && present(match[key]) && str(actual[key]) !== str(match[key])) result.mismatchFields.push(key);
    }
    result.status = result.mismatchFields.length ? 'identity_mismatch' : 'matched';
    return result;
  }

  function referenceProfileDiagnostic(result) {
    const nextStep = 'Load a matching referenceProfile (C#: ReferenceProfilePath), or supply the actual printTicket DTO.';
    switch (result.status) {
      case 'missing':
        return 'No reference profile was supplied to the mapper. Check that the approved RendererAssets/reference_profile.json is installed, or set ReferenceProfilePath to a matching profile. The booking response alone does not contain all exact ERS print fields.';
      case 'invalid_format':
        return 'A reference profile was supplied, but its format is invalid; expected irctc-reference-profile-v1. ' + nextStep;
      case 'invalid_identity':
        return 'A reference profile was supplied, but it has no usable ticket identity; missing or empty fields: ' + result.invalidFields.join(', ') + '. ' + nextStep;
      case 'identity_mismatch':
        return 'A reference profile was loaded but was not applied because it does not match this ticket; differing identity fields: ' + result.mismatchFields.join(', ') + '. ' + nextStep;
      default:
        return '';
    }
  }

  function referenceProfileError(message, result, missingFields = []) {
    const details = missingFields.length ? ' Missing print information: ' + missingFields.join('; ') : '';
    const error = new Error(message + referenceProfileDiagnostic(result) + details);
    error.code = 'IRCTC_REFERENCE_PROFILE_' + result.status.toUpperCase();
    error.referenceProfileStatus = result.status;
    error.referenceProfileMismatchFields = [...result.mismatchFields];
    error.referenceProfileInvalidFields = [...result.invalidFields];
    error.missingFields = [...missingFields];
    return error;
  }

  const normalizedText = x => str(x).normalize('NFC').trim().replace(/\s+/g, ' ').toUpperCase();
  const normalizedGender = x => ({MALE: 'M', FEMALE: 'F', TRANSGENDER: 'T'}[normalizedText(x)] || normalizedText(x));
  const normalizedStatus = x => normalizedText(x).replace(/[^A-Z0-9]/g, '');
  const codeFromLabel = x => /\(([A-Z0-9]+)\)\s*$/.exec(normalizedText(x))?.[1] || normalizedText(x).replace(/_/g, ' ');

  function money(value, field) {
    const text = str(value).trim().replace(/^(?:Rs\.?|INR|₹)\s*/i, '').replace(/,/g, '');
    if (!/^-?\d+(?:\.\d+)?$/.test(text) || !Number.isFinite(Number(text))) {
      throw new Error(`Reference integrity check could not parse ${field}; no profile data or QR was applied.`);
    }
    return Math.round(Number(text) * 100);
  }

  function fareCandidates(dto, input = {}) {
    const rows = array(dto.fareInfoData);
    const row = pattern => rows.filter(x => x && pattern.test(str(x.paramName))).map(x => x.message);
    const feeParts = present(dto.wpServiceCharge) && present(dto.wpServiceTax)
      ? (money(dto.wpServiceCharge, 'wpServiceCharge') + money(dto.wpServiceTax, 'wpServiceTax')) / 100 : undefined;
    return {
      totalFare: [dto.totalFare, ...row(/^Ticket Fare\s*$/i)].filter(present),
      serviceChargeTotal: [dto.serviceChargeTotal, feeParts, ...row(/^IRCTC Convenience Fee\b/i)].filter(present),
      totalCollectibleAmount: [dto.totalCollectibleAmount, input.totalCollectibleAmount, ...row(/^Total Fare\b/i)].filter(present),
      insuranceCharge: [dto.insuranceCharge, ...row(/^Travel Insurance\b/i)].filter(present)
    };
  }

  function assertMoneyCandidates(expected, values, field, required = true) {
    if (!present(expected)) return;
    if (required && values.length === 0) throw new Error(`Reference integrity check requires supplied ${field}; no profile data or QR was applied.`);
    const reference = money(expected, field);
    if (values.some(value => money(value, field) !== reference)) {
      throw new Error(`Reference profile conflicts with supplied ${field}; no profile data or QR was applied.`);
    }
  }

  function qrPassengers(qr) {
    const passengers = [];
    let passenger;
    for (const line of str(qr).split(/\r?\n/)) {
      const pair = /^\s*([^:]+):\s*(.*?)\s*,?\s*$/.exec(line);
      if (!pair) continue;
      const key = pair[1].trim(), value = pair[2].replace(/,\s*$/, '').trim();
      if (/^Passenger(?:\s+\d+)?\s+Name$/i.test(key)) {
        passenger = {passengerName: value}; passengers.push(passenger);
      } else if (passenger && /^Gender$/i.test(key)) passenger.passengerGender = value;
      else if (passenger && /^Age$/i.test(key)) passenger.passengerAge = value;
      else if (passenger && /^Status$/i.test(key)) passenger.status = value;
    }
    return passengers;
  }

  function assertPassengerFields(expected, actual, label) {
    if (!expected.length || expected.length !== actual.length) throw new Error(`${label} passenger count cannot be matched to supplied passengers; no profile data or QR was applied.`);
    for (let index = 0; index < expected.length; index++) {
      const ref = expected[index], supplied = actual[index];
      for (const key of ['passengerName', 'passengerAge', 'passengerGender', 'bookingStatus', 'bookingCoachId', 'bookingBerthNo', 'currentStatus', 'currentCoachId', 'currentBerthNo']) {
        if (!has(ref, key)) continue;
        const value = key === 'passengerGender' ? first(supplied.passengerGenderCode, supplied.passengerGender) : supplied[key];
        const normalize = key === 'passengerGender' ? normalizedGender : normalizedText;
        if (!present(value) || normalize(value) !== normalize(ref[key])) {
          throw new Error(`${label} conflicts with supplied passenger ${index + 1} ${key}; no profile data or QR was applied.`);
        }
      }
      if (has(ref, 'status')) {
        if (!present(supplied.currentStatus)) throw new Error(`${label} requires supplied current passenger status; no QR was applied.`);
        const status = normalizedStatus(str(supplied.currentStatus) + str(supplied.currentCoachId) + str(supplied.currentBerthNo));
        if (!present(ref.status) || normalizedStatus(ref.status) !== status) {
          throw new Error(`${label} conflicts with supplied passenger ${index + 1} current status/seat; no QR was applied.`);
        }
      }
    }
  }

  function assertQrFacts(qr, dto, label) {
    const identity = qrIdentity(qr);
    const expectedIdentity = {
      pnrNumber: dto.pnrNumber,
      transactionId: first(dto.mlTransactionID, dto.transactionID, dto.reservationId),
      trainNo: dto.trainNo,
      dateOfJourney: dto.dateOfJourney
    };
    for (const [key, value] of Object.entries(expectedIdentity)) {
      if (!present(value) || !present(identity[key]) || normalizedText(value) !== normalizedText(identity[key])) {
        throw new Error(`${label} identity field ${key} cannot be matched to the supplied ticket; no QR was applied.`);
      }
    }
    const passengers = qrPassengers(qr);
    if (passengers.some(x => !present(x.passengerName) || !present(x.passengerAge) || !present(x.passengerGender) || !present(x.status))) {
      throw new Error(`${label} passenger facts could not be parsed completely; no QR was applied.`);
    }
    assertPassengerFields(passengers, dto.passengerList, label);
    const fares = fareCandidates(dto);
    for (const [key, title] of [['totalFare', 'Ticket Fare'], ['serviceChargeTotal', 'IRCTC C Fee']]) {
      const text = qrField(qr, title);
      const amount = /(?:Rs\.?|INR|₹)\s*(-?\d+(?:\.\d+)?)/i.exec(str(text))?.[1];
      if (!present(amount)) throw new Error(`${label} ${title} could not be parsed; no QR was applied.`);
      assertMoneyCandidates(amount, fares[key], key);
    }
    for (const [title, value] of [['Class', dto.classCode], ['Quota', dto.quota]]) {
      if (!present(qrField(qr, title)) || codeFromLabel(qrField(qr, title)) !== codeFromLabel(value)) {
        throw new Error(`${label} conflicts with supplied ${title}; no QR was applied.`);
      }
    }
    if (scheduled(qrField(qr, 'Scheduled Departure')) !== dto.scheduledDepartureTime) {
      throw new Error(`${label} conflicts with supplied departure time; no QR was applied.`);
    }
    for (const [title, value] of [['From', dto.fromStation], ['To', dto.reservationUpto], ['Boarding Station', dto.boardingAt]]) {
      const code = /-\s*([A-Z0-9]+)\s*$/i.exec(str(qrField(qr, title)))?.[1];
      if (!present(value) || !code || normalizedText(code) !== normalizedText(value)) {
        throw new Error(`${label} conflicts with supplied ${title} station; no QR was applied.`);
      }
    }
  }

  function assertProfileFacts(profile, dto, input) {
    const expected = profile.ticketFacts || {};
    const referenceFares = fareCandidates(profile.printTicketFields || {});
    const suppliedFares = fareCandidates(dto, input);
    for (const key of ['totalFare', 'serviceChargeTotal', 'totalCollectibleAmount', 'insuranceCharge']) {
      const amount = first(expected[key], referenceFares[key][0]);
      assertMoneyCandidates(amount, suppliedFares[key], key, key !== 'insuranceCharge');
    }
    if (expected.passengerList) assertPassengerFields(array(expected.passengerList), dto.passengerList, 'Reference profile');
    else if (present(profile.qrCodeText)) assertQrFacts(profile.qrCodeText, dto, 'Reference profile QR');
  }

  function assertReferenceQr(profile, dto) {
    if (!present(profile.qrCodeText)) throw new Error('The matching reference profile has no decoded QR payload.');
    const expected = profile.match || {};
    const ref = qrIdentity(profile.qrCodeText);
    const supplied = qrIdentity(dto.qrCodeText);
    if (!ref.pnrNumber || str(ref.pnrNumber) !== str(dto.pnrNumber)) {
      throw new Error('Reference QR identity does not match the ticket; the supplied QR was not replaced.');
    }
    for (const key of ['pnrNumber', 'transactionId', 'trainNo', 'dateOfJourney']) {
      if (present(expected[key]) && present(ref[key]) && str(expected[key]) !== str(ref[key])) {
        throw new Error('Reference QR identity conflicts with its profile.');
      }
      if (present(supplied[key]) && present(ref[key]) && str(supplied[key]) !== str(ref[key])) {
        throw new Error('Supplied QR and reference QR identify different ticket facts; replacement was refused.');
      }
    }
    if (present(dto.qrCodeText) && !supplied.pnrNumber) {
      throw new Error('The supplied QR format could not be identity-checked; replacement was refused.');
    }
    assertQrFacts(profile.qrCodeText, dto, 'Reference QR');
    if (present(dto.qrCodeText)) assertQrFacts(dto.qrCodeText, dto, 'Supplied QR');
  }

  function normalizeIrctcTicket(input, options = {}) {
    if (typeof input === 'string') input = JSON.parse(input);
    if (!input || typeof input !== 'object' || Array.isArray(input)) throw new TypeError('Expected a booking response, printTicket DTO, or renderer model object.');
    const referenceDisabled = options.useReferenceProfile === false;
    if (referenceDisabled && options.useReferenceQr === true) {
      throw new Error('Reference QR cannot be selected when useReferenceProfile is false. The supplied JSON QR is used in JSON-only mode.');
    }
    const profile = referenceDisabled ? undefined : options.referenceProfile;
    const isBooking = has(input, 'bookingResponseDTO');
    const sourceKind = isBooking ? 'booking-response-adapter' : has(input, 'printTktResp') ? 'renderer-model-or-wrapped-print-dto' : 'print-ticket-dto';
    const notes = [];
    const missingFields = [];
    let dto;

    if (isBooking) {
      const bookings = array(input.bookingResponseDTO);
      if (bookings.length !== 1 || !bookings[0] || typeof bookings[0] !== 'object') {
        throw new Error('This normal-train adapter requires exactly one bookingResponseDTO. Supply the actual printTicket DTO for multi-lap tickets.');
      }
      const booking = bookings[0];
      dto = clone(booking);
      for (const source of [input.printTktResp, input]) {
        if (!source || typeof source !== 'object' || Array.isArray(source)) continue;
        for (const key of SUPPLIED_PRINT_FIELDS) {
          if (!has(dto, key) && has(source, key)) dto[key] = clone(source[key]);
        }
      }
      dto.trainNo = first(booking.trainNo, booking.trainNumber, dto.trainNo);
      dto.fromStation = first(booking.fromStation, booking.fromStn, dto.fromStation);
      dto.fromStationName = first(booking.fromStationName, booking.fromStnName, dto.fromStationName);
      dto.boardingAt = has(booking, 'boardingStn') ? booking.boardingStn : dto.boardingAt;
      dto.boardingAtName = has(booking, 'boardingStnName') ? booking.boardingStnName : dto.boardingAtName;
      dto.reservationUpto = first(booking.reservationUpto, booking.resvnUptoStn, booking.destStn, dto.reservationUpto);
      dto.reservationUptoName = first(booking.reservationUptoName, booking.resvnUptoStnName, booking.destStnName, dto.reservationUptoName);
      dto.mlTransactionID = first(dto.mlTransactionID, input.transactionId, booking.reservationId);
      dto.transactionID = first(dto.transactionID, dto.mlTransactionID);
      dto.qrCodeText = first(input.qrCodeText, booking.qrCodeText, dto.qrCodeText);
      dto.dateOfJourney = dateOnly(first(booking.dateOfJourney, booking.journeyDate, dto.dateOfJourney));
      dto.dateOfBooking = bookingDate(first(booking.dateOfBooking, booking.bookingDate, dto.dateOfBooking, input.bookingDate));
      dto.scheduledDepartureTime = scheduled(has(booking, 'boardingDate') ? booking.boardingDate : dto.scheduledDepartureTime, booking.departureTime);
      dto.scheduledArrivalTime = scheduled(first(booking.scheduledArrivalTime, booking.destArrvDate, dto.scheduledArrivalTime), booking.arrivalTime);
      dto.classCode = first(dto.classCode, qrField(dto.qrCodeText, 'Class')?.replace(/_/g, ' '), booking.journeyClass);
      dto.quota = first(dto.quota, qrField(dto.qrCodeText, 'Quota'),
        present(booking.bookedQuota) && present(booking.journeyQuota) ? `${booking.bookedQuota} (${booking.journeyQuota})` : undefined,
        booking.journeyQuota);
      dto.passengerList = array(has(booking, 'psgnDtlList') ? booking.psgnDtlList : dto.passengerList).map(passenger => ({
        ...clone(passenger),
        passengerGenderCode: first(passenger.passengerGenderCode, passenger.passengerGender)
      }));
      // Preserve explicit print fields and flags. Nested tax totals are copied
      // only under their identical names; IRCTC and PRS charges are not equated.
      if (booking.gstCharge && typeof booking.gstCharge === 'object' && !Array.isArray(booking.gstCharge)) {
        for (const key of ['taxableAmt', 'cgstRate', 'prsCgstCharge', 'sgstRate', 'prsSgstCharge', 'igstRate', 'prsIgstCharge', 'ugstRate', 'prsUgstCharge', 'totalPRSGst']) {
          if (!has(dto, key) && has(booking.gstCharge, key)) dto[key] = clone(booking.gstCharge[key]);
        }
      }
      notes.push('Booking fields and supplied print fields were adapted from the input JSON. Unavailable invoice, footer and advertisement data is not invented.');
      if (input._fixtureProvenance) notes.push('Input is explicitly labelled reconstructed from the reference; the original supplied booking JSON is unavailable.');
      for (const key of ['addOnOpted', 'dmrcBooking', 'multiLapFlag', 'postMealOpt']) {
        if (flag(booking[key]) === 'true') missingFields.push(`Unsupported booking branch: ${key}; supply the full printTicket DTO.`);
      }
    } else {
      dto = clone(input.printTktResp || input);
      dto.passengerList = array(dto.passengerList);
      dto.scheduledDepartureTime = scheduled(dto.scheduledDepartureTime);
      dto.scheduledArrivalTime = scheduled(dto.scheduledArrivalTime);
      if (!present(dto.qrCodeText) && present(input.qrCodeText)) dto.qrCodeText = input.qrCodeText;
    }

    const profileCheck = referenceDisabled
      ? {status: 'disabled', mismatchFields: [], invalidFields: []}
      : inspectReferenceProfile(profile, dto);
    const matchedProfile = profileCheck.status === 'matched';
    const supplement = matchedProfile && (isBooking || options.allowReferenceSupplementForPrintDto === true);
    if (!matchedProfile && (options.useReferenceProfile === true || (profile != null && options.requireComplete === true))) {
      throw referenceProfileError('A matching reference profile was requested but is unavailable. ', profileCheck);
    }
    if (profile != null && !matchedProfile) notes.push(referenceProfileDiagnostic(profileCheck));
    if (referenceDisabled) notes.push('Reference profile use is disabled; all ticket values come from the supplied JSON.');
    // Validate before applying any reference fields: the profile must not hide a
    // changed fare or passenger state behind an unchanged PNR/transaction ID.
    if (supplement || (matchedProfile && options.useReferenceQr === true)) assertProfileFacts(profile, dto, input);
    if (options.useReferenceQr === true && matchedProfile) assertReferenceQr(profile, dto);
    if (supplement) {
      // In the booking branch these are specifically PRINT fields from the
      // matching PDF. They may replace inferred labels, but not booking facts.
      const ignoredFields = [];
      for (const [key, value] of Object.entries(profile.printTicketFields || {})) {
        if (!REFERENCE_PRINT_FIELDS.has(key)) {
          ignoredFields.push(key);
          continue;
        }
        if (isBooking || !has(dto, key)) dto[key] = clone(value);
      }
      if (ignoredFields.length) notes.push('Reference fields outside the permitted print supplement were ignored: ' + ignoredFields.join(', ') + '. Boarding and passenger data remain from the supplied JSON.');
      notes.push('Print-only labels, invoice, instructions, and advertisements were supplemented from the matching user reference PDF.');
    }

    let qrSource = present(dto.qrCodeText) ? 'supplied-input' : 'missing';
    if (options.useReferenceQr === true) {
      if (!matchedProfile) throw referenceProfileError('Explicit reference QR replacement requires a matching reference profile. ', profileCheck);
      const changed = dto.qrCodeText !== profile.qrCodeText;
      dto.qrCodeText = profile.qrCodeText;
      qrSource = 'reference-pdf-explicit-option';
      notes.push(changed ? 'The decoded reference QR was explicitly selected; its bytes differ from the supplied QR.' : 'The decoded reference QR was explicitly selected and already matches the supplied QR.');
    } else if (!present(dto.qrCodeText) && supplement && present(profile.qrCodeText)) {
      // Filling a missing QR from a matching reference also requires opt-in.
      notes.push('A reference QR is available, but useReferenceQr was not enabled; no payload was silently inserted.');
    }

    if (!has(dto, 'cancellationID')) dto.cancellationID = '0';
    if (!has(dto, 'addOnCancellationId')) dto.addOnCancellationId = '0';
    if (!has(dto, 'addonServiceFlag')) dto.addonServiceFlag = '0';
    if (!has(dto, 'trainOwnerFlag')) dto.trainOwnerFlag = first(dto.trainOwner, '0');
    for (const key of ['railGreenPointFlag', 'gsaFlag', 'travelAgentFlag', 'ecsFlag', 'displayMPPhoto', 'dmrcOptedFlag']) {
      if (!has(dto, key)) dto[key] = 'false';
    }
    if (!has(dto, 'gstFlag')) dto.gstFlag = 'false';
    if (!has(dto, 'scheduleDepartureFlag')) dto.scheduleDepartureFlag = present(dto.scheduledDepartureTime) ? 'true' : 'false';
    if (!has(dto, 'scheduleArrivalFlag')) dto.scheduleArrivalFlag = present(dto.scheduledArrivalTime) ? 'true' : 'false';
    if (!has(dto, 'accommodationStatus')) {
      dto.accommodationStatus = clone(ACRONYMS);
      notes.push('Missing English acronym expansions use captured labels_en.json (rlWl, pqWl, rsWl).');
    }

    if (!has(dto, 'fareInfoData') && isBooking) {
      const fee = first(dto.serviceChargeTotal,
        present(dto.wpServiceCharge) && present(dto.wpServiceTax) ? String(Number(dto.wpServiceCharge) + Number(dto.wpServiceTax)) : undefined);
      const total = first(dto.totalCollectibleAmount, input.totalCollectibleAmount);
      const rows = [];
      if (present(dto.totalFare)) rows.push({paramName: 'Ticket Fare', message: dto.totalFare});
      if (present(fee)) rows.push({paramName: 'IRCTC Convenience Fee (Incl. of GST)', message: fee});
      if (present(dto.insuranceCharge) && Number(dto.insuranceCharge) !== 0) rows.push({paramName: 'Travel Insurance Premium', message: dto.insuranceCharge});
      if (present(total)) rows.push({paramName: 'Total Fare (all inclusive)', message: total});
      dto.fareInfoData = rows;
      notes.push('Fare rows were reconstructed from booking amounts; reservationCharge is already included in totalFare and was not added again. Zero insurance was not made into an extra row. Exact server fareInfoData is unavailable.');
    }
    for (const key of ['bottomTicketMessage', 'fundmntlTicketMessage', 'ticketLegendMessage', 'fareInfoData', 'ersLogosEnglish', 'cancelFareDetail', 'metroPassengerList']) {
      dto[key] = array(dto[key]);
    }
    if (flag(dto.gstFlag) === 'true' && (!dto.gstDetailsDTO || typeof dto.gstDetailsDTO !== 'object')) {
      missingFields.push('gstDetailsDTO: GST display is enabled but recipient data is absent.');
      dto.gstDetailsDTO = {};
    }
    for (const key of ['pnrNumber', 'trainNo', 'trainName', 'fromStationName', 'boardingAt', 'boardingAtName', 'reservationUptoName', 'dateOfJourney', 'dateOfBooking', 'classCode', 'quota', 'mlTransactionID', 'qrCodeText']) {
      if (!present(dto[key])) missingFields.push(key);
    }
    if (dto.passengerList.length === 0) missingFields.push('passengerList');
    if (dto.fareInfoData.length === 0) missingFields.push('fareInfoData');

    const suppliedContext = input.printTktResp ? clone(input) : {};
    const component = supplement ? clone(profile.componentFields || {}) : {};
    const information = first(suppliedContext.userInfoMessage, component.userInfoMessage,
      input.userDetail && input.userDetail.informationMessage, []);
    const context = {
      ...suppliedContext,
      printTktResp: dto,
      lng: first(suppliedContext.lng, 'en'),
      passengerList: dto.passengerList,
      psgnDtlList: dto.passengerList,
      accommodationStatus: array(dto.accommodationStatus),
      fareInfoData: dto.fareInfoData,
      bottomTktMsg: dto.bottomTicketMessage,
      fundmntlTktMsg: dto.fundmntlTicketMessage,
      ticketLegendMessage: dto.ticketLegendMessage,
      ticketLegendMsg: dto.ticketLegendMessage,
      CancellationRefundData: dto.cancelFareDetail,
      metroPassengerList: dto.metroPassengerList,
      userInfoMessage: array(information).filter(x => x && x.paramName === 'ERS'),
      pledge: false,
      pledgeMessage: first(suppliedContext.pledgeMessage, component.pledgeMessage, ''),
      iframeVisible: options.iframeVisible ?? suppliedContext.iframeVisible ?? component.iframeVisible ?? true,
      refreshPopup: false,
      alertFlag: false,
      txnTypeFlagDmrc: true,
      dmrcQrOnlyPrint: false,
      dmrcEcsFlag: false,
      enableFood: flag(first(suppliedContext.enableFood, dto.enableFood)),
      enableBedRoll: flag(first(suppliedContext.enableBedRoll, dto.enableBedRoll)),
      concessionOption: flag(first(suppliedContext.concessionOption, dto.concessionOption)),
      bedrollChoice: flag(first(suppliedContext.bedrollChoice, dto.bedrollChoice)),
      displayMpPhoto: flag(first(suppliedContext.displayMpPhoto, dto.displayMpPhoto)),
      fromStationFlag: flag(first(suppliedContext.fromStationFlag, dto.fromStationFlag)),
      toStationFlag: flag(first(suppliedContext.toStationFlag, dto.toStationFlag)),
      agentUserFlag: false,
      hideMessage: false,
      getAgentData: false,
      langService: suppliedContext.langService || {langChoice: 'en', lang: {}},
    };
    for (const key of ['scheduleDepartureFlag', 'scheduleArrivalFlag', 'travelAgentFlag', 'gstFlag', 'ecsFlag', 'tatkalIDChoice', 'gstDisplay', 'userGroupTypeIdFlag', 'codPaymentMsgFlag', 'pmfAgentFlage', 'displayCateringFlag']) {
      context[key] = flag(first(suppliedContext[key], dto[key]));
    }
    context._normalization = {
      format: 'irctc-normalized-renderer-model-v2', sourceKind,
      reconstructedInput: Boolean(input._fixtureProvenance?.reconstructed),
      referenceProfileStatus: profileCheck.status,
      referenceProfileMismatchFields: [...profileCheck.mismatchFields],
      referenceProfileInvalidFields: [...profileCheck.invalidFields],
      referenceProfileMatched: matchedProfile,
      referenceProfileApplied: supplement,
      qrSource,
      qrLength: str(dto.qrCodeText).length,
      localDateHandling: 'Ticket-local text; no timezone conversion. Scheduled dates use the final displayed order.',
      defaults: 'Missing normal-booking cancellation/add-on flags default to zero; missing normal-user display flags default to false. No berth type or invoice number is synthesized.',
      missingFields,
      notes,
      omitUnavailableTaxStateRow: ['prsSuplierState', 'prsSuplierStateCode', 'gstStateName', 'gstStateCode'].every(key => !present(dto[key])),
    };
    if (options.requireComplete === true && missingFields.length) {
      if (isBooking && !supplement && !referenceDisabled && profile != null) {
        throw referenceProfileError('Required print information is unavailable: ', profileCheck, missingFields);
      }
      throw new Error('Required print information is unavailable: ' + missingFields.join('; '));
    }
    return context;
  }

  if (typeof module !== 'undefined' && module.exports) module.exports = {normalizeIrctcTicket};
  root.normalizeIrctcTicket = normalizeIrctcTicket;
})(typeof globalThis !== 'undefined' ? globalThis : this);
